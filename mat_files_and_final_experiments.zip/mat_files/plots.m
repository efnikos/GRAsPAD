
[X,Y] = meshgrid([min(phi) max(phi)],[min(theta) max(theta)],10000)
##Vq = interp2(phi,theta,partial_rewards,X,Y)

size(phi)
size(theta)
size(partial_rewards)

